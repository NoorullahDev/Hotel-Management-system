-- Backup Generated on 2026-07-20T21:09:55.768Z

-- DELETE ALL ROWS
DELETE FROM "AuditLog";
DELETE FROM "NotificationPreference";
DELETE FROM "Notification";
DELETE FROM "Feedback";
DELETE FROM "OrderItem";
DELETE FROM "FoodOrder";
DELETE FROM "InvoiceItem";
DELETE FROM "Invoice";
DELETE FROM "Payment";
DELETE FROM "HousekeepingTask";
DELETE FROM "RoomMaintenance";
DELETE FROM "Booking";
DELETE FROM "Room";
DELETE FROM "Staff";
DELETE FROM "User";
DELETE FROM "Guest";
DELETE FROM "RoomType";
DELETE FROM "MenuCategory";
DELETE FROM "MenuItem";
DELETE FROM "HotelSettings";
DELETE FROM "Setting";
DELETE FROM "Role";

-- Table: Role
INSERT INTO "Role" ("id", "name", "permissions") VALUES ('2df3d2ba-8355-488a-8d3f-0b5a65c8963d', 'Admin', '[]');
INSERT INTO "Role" ("id", "name", "permissions") VALUES ('4ba193e2-2ac6-4923-972d-57aa141b1175', 'Manager', '[]');
INSERT INTO "Role" ("id", "name", "permissions") VALUES ('58866c98-5a38-461b-9a93-1a70d7391f8e', 'Receptionist', '[]');
INSERT INTO "Role" ("id", "name", "permissions") VALUES ('a68b4cd8-bd2b-4512-add0-1d04c287ce4a', 'Housekeeping', '[]');
INSERT INTO "Role" ("id", "name", "permissions") VALUES ('2a88dfa5-89b3-45ff-b575-fcb1d7ae139b', 'Restaurant', '[]');

-- Table: Setting
INSERT INTO "Setting" ("key", "category", "value") VALUES ('hotelLogo', 'general', '/uploads/1784580129830-WhatsApp_Image_2026-07-20_at_12.07.33_PM.jpeg');
INSERT INTO "Setting" ("key", "category", "value") VALUES ('hotelBanner', 'general', '/uploads/1784580137463-WhatsApp_Image_2026-07-20_at_12.07.32_PM.jpeg');
INSERT INTO "Setting" ("key", "category", "value") VALUES ('hotelName', 'general', 'Farooq Hotel');
INSERT INTO "Setting" ("key", "category", "value") VALUES ('hotelAddress', 'general', 'Gabin Jabba, Swat');
INSERT INTO "Setting" ("key", "category", "value") VALUES ('lastBackupAt', 'system', '2026-07-20T21:09:51.955Z');

-- Table: HotelSettings
INSERT INTO "HotelSettings" ("id", "name", "taxRate", "currency", "defaultCheckIn", "defaultCheckOut", "loginBackgroundImage") VALUES ('27528be5-3329-4529-9df2-0f5047286af6', 'Grand Park Hotel', 0.1, 'PKR', '14:00', '11:00', NULL);

-- Table: MenuCategory
INSERT INTO "MenuCategory" ("id", "name") VALUES ('c724b117-3aa2-4d7f-89e8-cf30f511ef80', 'Starter');
INSERT INTO "MenuCategory" ("id", "name") VALUES ('c8660a0a-502d-4c90-a42f-5bce9dc14214', 'Main Course');
INSERT INTO "MenuCategory" ("id", "name") VALUES ('f179bddf-4722-4fe7-8f5d-d6029ebb5e4b', 'Beverage');
INSERT INTO "MenuCategory" ("id", "name") VALUES ('fab55766-3795-404d-9857-2a06755c1b00', 'Dessert');

-- Table: RoomType
INSERT INTO "RoomType" ("id", "name") VALUES ('9b7fe485-2898-4526-960a-bcbf55c227a3', 'Single');
INSERT INTO "RoomType" ("id", "name") VALUES ('8adaa189-509b-4aa4-9b4b-edb2e3fcabfd', 'Double');
INSERT INTO "RoomType" ("id", "name") VALUES ('0872af3f-2cd6-4f01-a3fc-fb5ed4d28cd0', 'Deluxe');
INSERT INTO "RoomType" ("id", "name") VALUES ('acc7542b-89cd-4081-8342-0010f45601de', 'Suite');

-- Table: Guest
INSERT INTO "Guest" ("id", "guestType", "name", "email", "phone", "idType", "idNumber", "nationality", "city", "country", "address", "notes") VALUES ('f54b87d1-e600-4ac8-b042-d88acc706ecd', 'LOCAL', 'John Doe', 'john@example.com', '1234567890', NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO "Guest" ("id", "guestType", "name", "email", "phone", "idType", "idNumber", "nationality", "city", "country", "address", "notes") VALUES ('f5a4d675-5a04-4514-9243-a862e94701e3', 'LOCAL', 'Jane Smith', 'jane@example.com', '0987654321', NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO "Guest" ("id", "guestType", "name", "email", "phone", "idType", "idNumber", "nationality", "city", "country", "address", "notes") VALUES ('2c125512-18c6-446d-894c-1b2262895835', 'LOCAL', 'Alice Johnson', 'alice@example.com', '5551234567', NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO "Guest" ("id", "guestType", "name", "email", "phone", "idType", "idNumber", "nationality", "city", "country", "address", "notes") VALUES ('c18fb966-79f2-4e41-96de-9ac536ab1f58', 'LOCAL', 'noor', NULL, '45678943', 'CNIC', '4567829387463', 'Pakistani', 'swat', NULL, NULL, NULL);
INSERT INTO "Guest" ("id", "guestType", "name", "email", "phone", "idType", "idNumber", "nationality", "city", "country", "address", "notes") VALUES ('09987669-e8a6-468c-aa70-d5787086f2e8', 'FOREIGN', 'smith', NULL, '6788945678', 'Passport', '3456789876', 'aus', '', 'aus', NULL, NULL);
INSERT INTO "Guest" ("id", "guestType", "name", "email", "phone", "idType", "idNumber", "nationality", "city", "country", "address", "notes") VALUES ('6e09a506-ec9d-426c-910a-77c4fbc82764', 'FOREIGN', 'ygjh', NULL, '78653456', 'Passport', '3456ygg', 'gh', '', 'fgh', NULL, NULL);

-- Table: User
INSERT INTO "User" ("id", "email", "name", "phone", "profilePhoto", "roleId", "oauthProvider", "failedLoginAttempts", "lockedUntil", "passwordHash") VALUES ('b0011f32-03b6-46c7-bc71-67e75a91a177', 'Noorullah1245', 'Noorullah', '', '/uploads/1784575214389-WhatsApp_Image_2026-07-20_at_12.19.34_PM.jpeg', '2df3d2ba-8355-488a-8d3f-0b5a65c8963d', NULL, 0, NULL, '$2b$10$dMymyibZvvmdnVZcZuqbsulMQCFDVsSMXRHrRQmehjutjf1aQnT4i');

-- Table: Room
INSERT INTO "Room" ("id", "number", "floor", "roomTypeId", "price", "status", "amenities", "imageUrl") VALUES ('c52b0205-2b17-40a5-bbae-39986685b2a7', '101', 1, '9b7fe485-2898-4526-960a-bcbf55c227a3', 10000, 'OCCUPIED', '["Wi-Fi","TV","Air Conditioning"]', NULL);
INSERT INTO "Room" ("id", "number", "floor", "roomTypeId", "price", "status", "amenities", "imageUrl") VALUES ('d6412130-4fa9-4fab-88d0-ab32d04a250a', '102', 1, '8adaa189-509b-4aa4-9b4b-edb2e3fcabfd', 1500, 'OCCUPIED', '["Wi-Fi","TV","Air Conditioning"]', NULL);
INSERT INTO "Room" ("id", "number", "floor", "roomTypeId", "price", "status", "amenities", "imageUrl") VALUES ('91c875fe-528b-4ae0-9798-e2fe2f8c9d86', '103', 1, '0872af3f-2cd6-4f01-a3fc-fb5ed4d28cd0', 2500, 'OCCUPIED', '["Wi-Fi","TV","Air Conditioning"]', NULL);
INSERT INTO "Room" ("id", "number", "floor", "roomTypeId", "price", "status", "amenities", "imageUrl") VALUES ('f8aa2f17-0e95-420e-b4e7-acdc9122f9fa', '104', 1, 'acc7542b-89cd-4081-8342-0010f45601de', 5000, 'OCCUPIED', '["Wi-Fi","TV","Air Conditioning"]', NULL);
INSERT INTO "Room" ("id", "number", "floor", "roomTypeId", "price", "status", "amenities", "imageUrl") VALUES ('7a5678c8-1542-4479-9741-9b24a7a7bceb', '105', 1, '9b7fe485-2898-4526-960a-bcbf55c227a3', 100, 'AVAILABLE', '["Wi-Fi","TV","Air Conditioning"]', NULL);
INSERT INTO "Room" ("id", "number", "floor", "roomTypeId", "price", "status", "amenities", "imageUrl") VALUES ('c485a84f-2e6a-4a2c-a6dd-8be9deb1c9ef', '106', 1, '8adaa189-509b-4aa4-9b4b-edb2e3fcabfd', 150, 'AVAILABLE', '["Wi-Fi","TV","Air Conditioning"]', NULL);
INSERT INTO "Room" ("id", "number", "floor", "roomTypeId", "price", "status", "amenities", "imageUrl") VALUES ('107895bf-849a-4531-bd7e-c2a4ef0a140e', '107', 1, '0872af3f-2cd6-4f01-a3fc-fb5ed4d28cd0', 250, 'OCCUPIED', '["Wi-Fi","TV","Air Conditioning"]', NULL);
INSERT INTO "Room" ("id", "number", "floor", "roomTypeId", "price", "status", "amenities", "imageUrl") VALUES ('83b6f66e-61ab-474a-87aa-3ff1418dbe25', '108', 1, 'acc7542b-89cd-4081-8342-0010f45601de', 500, 'AVAILABLE', '["Wi-Fi","TV","Air Conditioning"]', NULL);
INSERT INTO "Room" ("id", "number", "floor", "roomTypeId", "price", "status", "amenities", "imageUrl") VALUES ('5c445970-c6a4-438d-90b2-026137ee3c90', '109', 1, '9b7fe485-2898-4526-960a-bcbf55c227a3', 100, 'AVAILABLE', '["Wi-Fi","TV","Air Conditioning"]', NULL);
INSERT INTO "Room" ("id", "number", "floor", "roomTypeId", "price", "status", "amenities", "imageUrl") VALUES ('3666009c-a082-44df-9d9c-0b3f7142f47c', '110', 1, '8adaa189-509b-4aa4-9b4b-edb2e3fcabfd', 150, 'AVAILABLE', '["Wi-Fi","TV","Air Conditioning"]', NULL);
INSERT INTO "Room" ("id", "number", "floor", "roomTypeId", "price", "status", "amenities", "imageUrl") VALUES ('0722e0af-3491-4ff6-9e65-a9ee2e6c41c9', '201', 2, '0872af3f-2cd6-4f01-a3fc-fb5ed4d28cd0', 250, 'AVAILABLE', '["Wi-Fi","TV","Air Conditioning"]', NULL);
INSERT INTO "Room" ("id", "number", "floor", "roomTypeId", "price", "status", "amenities", "imageUrl") VALUES ('386f839a-a861-445b-ab4e-82b89e7b5581', '202', 2, 'acc7542b-89cd-4081-8342-0010f45601de', 500, 'AVAILABLE', '["Wi-Fi","TV","Air Conditioning"]', NULL);
INSERT INTO "Room" ("id", "number", "floor", "roomTypeId", "price", "status", "amenities", "imageUrl") VALUES ('7088ffab-6212-4865-939a-c9a530cf72ca', '203', 2, '9b7fe485-2898-4526-960a-bcbf55c227a3', 100, 'AVAILABLE', '["Wi-Fi","TV","Air Conditioning"]', NULL);
INSERT INTO "Room" ("id", "number", "floor", "roomTypeId", "price", "status", "amenities", "imageUrl") VALUES ('a53be9e2-3fa6-4205-9a8e-5aee46e2db9f', '204', 2, '8adaa189-509b-4aa4-9b4b-edb2e3fcabfd', 150, 'AVAILABLE', '["Wi-Fi","TV","Air Conditioning"]', NULL);
INSERT INTO "Room" ("id", "number", "floor", "roomTypeId", "price", "status", "amenities", "imageUrl") VALUES ('d0188967-8edc-48cc-8005-066828eb9c95', '205', 2, '0872af3f-2cd6-4f01-a3fc-fb5ed4d28cd0', 250, 'AVAILABLE', '["Wi-Fi","TV","Air Conditioning"]', NULL);
INSERT INTO "Room" ("id", "number", "floor", "roomTypeId", "price", "status", "amenities", "imageUrl") VALUES ('542fa70f-da68-443f-bfc4-97202d79f26e', '206', 2, 'acc7542b-89cd-4081-8342-0010f45601de', 500, 'AVAILABLE', '["Wi-Fi","TV","Air Conditioning"]', NULL);
INSERT INTO "Room" ("id", "number", "floor", "roomTypeId", "price", "status", "amenities", "imageUrl") VALUES ('72a2334a-855b-4ccd-8af4-2d9409c44853', '207', 2, '9b7fe485-2898-4526-960a-bcbf55c227a3', 100, 'AVAILABLE', '["Wi-Fi","TV","Air Conditioning"]', NULL);
INSERT INTO "Room" ("id", "number", "floor", "roomTypeId", "price", "status", "amenities", "imageUrl") VALUES ('5aae2cb0-28e1-48d8-bdac-108fd6d8d9d5', '208', 2, '8adaa189-509b-4aa4-9b4b-edb2e3fcabfd', 150, 'AVAILABLE', '["Wi-Fi","TV","Air Conditioning"]', NULL);
INSERT INTO "Room" ("id", "number", "floor", "roomTypeId", "price", "status", "amenities", "imageUrl") VALUES ('aad472c4-28a7-4c7a-b63c-a8d11ebf804a', '209', 2, '0872af3f-2cd6-4f01-a3fc-fb5ed4d28cd0', 250, 'AVAILABLE', '["Wi-Fi","TV","Air Conditioning"]', NULL);
INSERT INTO "Room" ("id", "number", "floor", "roomTypeId", "price", "status", "amenities", "imageUrl") VALUES ('b4e4a963-b703-4ae2-ae71-04cb01317890', '210', 2, 'acc7542b-89cd-4081-8342-0010f45601de', 500, 'AVAILABLE', '["Wi-Fi","TV","Air Conditioning"]', NULL);
INSERT INTO "Room" ("id", "number", "floor", "roomTypeId", "price", "status", "amenities", "imageUrl") VALUES ('4602eb9f-fb30-4421-95cf-f0b87ae2186b', '129', 3, 'acc7542b-89cd-4081-8342-0010f45601de', 18888, 'AVAILABLE', '["All"]', NULL);

-- Table: Booking
INSERT INTO "Booking" ("id", "bookingType", "guestId", "roomId", "checkIn", "checkOut", "arrivalTime", "guestCount", "additionalGuests", "status", "subtotal", "tax", "total", "createdAt") VALUES ('83428ce3-cdd0-4a6c-b3da-b2b37a8ed99f', 'LOCAL', 'f54b87d1-e600-4ac8-b042-d88acc706ecd', 'c52b0205-2b17-40a5-bbae-39986685b2a7', '2026-07-20T21:00:00.000Z', '2026-07-21T18:00:00.000Z', NULL, 1, NULL, 'CHECKED_IN', 100, 10, 110, '2026-07-20T12:12:47.373Z');
INSERT INTO "Booking" ("id", "bookingType", "guestId", "roomId", "checkIn", "checkOut", "arrivalTime", "guestCount", "additionalGuests", "status", "subtotal", "tax", "total", "createdAt") VALUES ('9f69b889-2fa2-41f0-a83b-5f3ccfc37d1b', 'LOCAL', 'f5a4d675-5a04-4514-9243-a862e94701e3', 'd6412130-4fa9-4fab-88d0-ab32d04a250a', '2026-07-19T21:00:00.000Z', '2026-07-21T18:00:00.000Z', NULL, 2, NULL, 'CHECKED_IN', 300, 30, 330, '2026-07-20T12:12:47.517Z');
INSERT INTO "Booking" ("id", "bookingType", "guestId", "roomId", "checkIn", "checkOut", "arrivalTime", "guestCount", "additionalGuests", "status", "subtotal", "tax", "total", "createdAt") VALUES ('5108bb89-4454-4d71-9196-215a58655b30', 'LOCAL', '2c125512-18c6-446d-894c-1b2262895835', '91c875fe-528b-4ae0-9798-e2fe2f8c9d86', '2026-07-21T21:00:00.000Z', '2026-07-23T21:00:00.000Z', NULL, 1, NULL, 'CHECKED_IN', 750, 75, 825, '2026-07-20T12:12:47.647Z');
INSERT INTO "Booking" ("id", "bookingType", "guestId", "roomId", "checkIn", "checkOut", "arrivalTime", "guestCount", "additionalGuests", "status", "subtotal", "tax", "total", "createdAt") VALUES ('4a263cc8-1364-4539-bb14-b9e641723a2d', 'LOCAL', 'c18fb966-79f2-4e41-96de-9ac536ab1f58', 'f8aa2f17-0e95-420e-b4e7-acdc9122f9fa', '2026-07-20T00:00:00.000Z', '2026-07-21T00:00:00.000Z', NULL, 2, NULL, 'CHECKED_IN', 5000, 0, 4970, '2026-07-20T19:22:03.641Z');
INSERT INTO "Booking" ("id", "bookingType", "guestId", "roomId", "checkIn", "checkOut", "arrivalTime", "guestCount", "additionalGuests", "status", "subtotal", "tax", "total", "createdAt") VALUES ('64fb0df6-b5b5-4f86-a2c0-d22531630210', 'FOREIGN', '09987669-e8a6-468c-aa70-d5787086f2e8', '107895bf-849a-4531-bd7e-c2a4ef0a140e', '2026-07-20T14:00:00.000Z', '2026-07-21T12:00:00.000Z', '2026-07-20T14:00:00.000Z', 2, NULL, 'CHECKED_IN', 250, 0, 220, '2026-07-20T19:23:23.313Z');
INSERT INTO "Booking" ("id", "bookingType", "guestId", "roomId", "checkIn", "checkOut", "arrivalTime", "guestCount", "additionalGuests", "status", "subtotal", "tax", "total", "createdAt") VALUES ('27823daa-fc83-4a0b-9cd4-6c0e1a0e73c2', 'FOREIGN', '6e09a506-ec9d-426c-910a-77c4fbc82764', '91c875fe-528b-4ae0-9798-e2fe2f8c9d86', '2026-07-20T14:00:00.000Z', '2026-07-21T12:00:00.000Z', '2026-07-20T14:00:00.000Z', 2, NULL, 'CHECKED_IN', 2500, 0, 2470, '2026-07-20T20:17:27.287Z');

-- Table: Payment
INSERT INTO "Payment" ("id", "bookingId", "amount", "method", "createdAt") VALUES ('5465e807-6434-422e-b60a-2ffa452357dd', '4a263cc8-1364-4539-bb14-b9e641723a2d', 4970, 'Cash', '2026-07-20T19:22:03.641Z');
INSERT INTO "Payment" ("id", "bookingId", "amount", "method", "createdAt") VALUES ('b87e038f-605c-42a0-aa6d-a3ddf0721d4a', '64fb0df6-b5b5-4f86-a2c0-d22531630210', 220, 'Cash', '2026-07-20T19:23:23.313Z');
INSERT INTO "Payment" ("id", "bookingId", "amount", "method", "createdAt") VALUES ('4e240051-ebb6-4e1b-b3fd-2cd91389dfd0', '27823daa-fc83-4a0b-9cd4-6c0e1a0e73c2', 2470, 'Cash', '2026-07-20T20:17:27.287Z');

-- Table: Notification
INSERT INTO "Notification" ("id", "userId", "type", "title", "message", "referenceId", "metadata", "isRead", "createdAt") VALUES ('d68b640c-293a-469f-a6cf-e47ea7a03918', 'b0011f32-03b6-46c7-bc71-67e75a91a177', 'Booking', 'New booking created', 'A new booking has been created by noor for Room 104.', '4a263cc8-1364-4539-bb14-b9e641723a2d', '{"Booking ID":"4A263CC8-1364","Guest Name":"noor","Room Number":"104","Check-in Date":"Jul 19, 2026","Check-out Date":"Jul 20, 2026","Total Amount":"Rs. 4,970","Created At":"Jul 20, 2026, 12:22 PM"}', false, '2026-07-20T19:22:03.804Z');
INSERT INTO "Notification" ("id", "userId", "type", "title", "message", "referenceId", "metadata", "isRead", "createdAt") VALUES ('f3151cd6-b37e-47cf-b1a6-3bc4a6ae738d', 'b0011f32-03b6-46c7-bc71-67e75a91a177', 'Booking', 'New booking created', 'A new booking has been created by smith for Room 107.', '64fb0df6-b5b5-4f86-a2c0-d22531630210', '{"Booking ID":"64FB0DF6-B5B5","Guest Name":"smith","Room Number":"107","Check-in Date":"Jul 20, 2026","Check-out Date":"Jul 21, 2026","Total Amount":"Rs. 220","Created At":"Jul 20, 2026, 12:23 PM"}', false, '2026-07-20T19:23:23.466Z');
INSERT INTO "Notification" ("id", "userId", "type", "title", "message", "referenceId", "metadata", "isRead", "createdAt") VALUES ('c7039663-71ac-4f40-a61a-9057312e145b', 'b0011f32-03b6-46c7-bc71-67e75a91a177', 'Booking', 'New booking created', 'A new booking has been created by ygjh for Room 103.', '27823daa-fc83-4a0b-9cd4-6c0e1a0e73c2', '{"Booking ID":"27823DAA-FC83","Guest Name":"ygjh","Room Number":"103","Check-in Date":"Jul 20, 2026","Check-out Date":"Jul 21, 2026","Total Amount":"Rs. 2,470","Created At":"Jul 20, 2026, 1:17 PM"}', false, '2026-07-20T20:17:27.512Z');
INSERT INTO "Notification" ("id", "userId", "type", "title", "message", "referenceId", "metadata", "isRead", "createdAt") VALUES ('15d701db-2757-46e9-b11f-b746f56a759d', 'b0011f32-03b6-46c7-bc71-67e75a91a177', 'Check-in', 'Guest checked in', 'ygjh has checked in to Room 103.', '27823daa-fc83-4a0b-9cd4-6c0e1a0e73c2', '{"Booking ID":"27823DAA-FC83","Guest Name":"ygjh","Room Number":"103","Check-in Date":"Jul 20, 2026","Check-out Date":"Jul 21, 2026","Total Amount":"Rs. 2,470","Created At":"Jul 20, 2026, 1:18 PM"}', false, '2026-07-20T20:18:02.282Z');
INSERT INTO "Notification" ("id", "userId", "type", "title", "message", "referenceId", "metadata", "isRead", "createdAt") VALUES ('9e706a46-1a9f-488f-bfcc-98d208f42d7b', 'b0011f32-03b6-46c7-bc71-67e75a91a177', 'Check-in', 'Guest checked in', 'smith has checked in to Room 107.', '64fb0df6-b5b5-4f86-a2c0-d22531630210', '{"Booking ID":"64FB0DF6-B5B5","Guest Name":"smith","Room Number":"107","Check-in Date":"Jul 20, 2026","Check-out Date":"Jul 21, 2026","Total Amount":"Rs. 220","Created At":"Jul 20, 2026, 1:18 PM"}', false, '2026-07-20T20:18:10.034Z');
INSERT INTO "Notification" ("id", "userId", "type", "title", "message", "referenceId", "metadata", "isRead", "createdAt") VALUES ('48e0f024-6a86-492e-b8d4-c143c36eaa97', 'b0011f32-03b6-46c7-bc71-67e75a91a177', 'Check-in', 'Guest checked in', 'noor has checked in to Room 104.', '4a263cc8-1364-4539-bb14-b9e641723a2d', '{"Booking ID":"4A263CC8-1364","Guest Name":"noor","Room Number":"104","Check-in Date":"Jul 19, 2026","Check-out Date":"Jul 20, 2026","Total Amount":"Rs. 4,970","Created At":"Jul 20, 2026, 1:18 PM"}', false, '2026-07-20T20:18:16.036Z');
INSERT INTO "Notification" ("id", "userId", "type", "title", "message", "referenceId", "metadata", "isRead", "createdAt") VALUES ('981737a2-fc54-45e4-8244-4dd07c08d38a', 'b0011f32-03b6-46c7-bc71-67e75a91a177', 'Check-in', 'Guest checked in', 'Alice Johnson has checked in to Room 103.', '5108bb89-4454-4d71-9196-215a58655b30', '{"Booking ID":"5108BB89-4454","Guest Name":"Alice Johnson","Room Number":"103","Check-in Date":"Jul 21, 2026","Check-out Date":"Jul 23, 2026","Total Amount":"Rs. 825","Created At":"Jul 20, 2026, 1:18 PM"}', false, '2026-07-20T20:18:23.638Z');
INSERT INTO "Notification" ("id", "userId", "type", "title", "message", "referenceId", "metadata", "isRead", "createdAt") VALUES ('5efd87e4-6367-473a-b7db-d22ab0073b5f', 'b0011f32-03b6-46c7-bc71-67e75a91a177', 'Check-in', 'Guest checked in', 'John Doe has checked in to Room 101.', '83428ce3-cdd0-4a6c-b3da-b2b37a8ed99f', '{"Booking ID":"83428CE3-CDD0","Guest Name":"John Doe","Room Number":"101","Check-in Date":"Jul 20, 2026","Check-out Date":"Jul 21, 2026","Total Amount":"Rs. 110","Created At":"Jul 20, 2026, 1:18 PM"}', false, '2026-07-20T20:18:29.736Z');

-- Table: NotificationPreference
INSERT INTO "NotificationPreference" ("id", "userId", "booking", "checkIn", "checkOut", "roomReady", "foodOrder", "feedback", "system", "payment", "maintenance", "staff", "emergency", "email", "sms", "desktop") VALUES ('0c5e29a7-b305-4874-b82a-f068efd79991', 'b0011f32-03b6-46c7-bc71-67e75a91a177', true, true, true, true, true, true, true, true, true, true, true, true, false, true);

-- Table: AuditLog
INSERT INTO "AuditLog" ("id", "userId", "action", "module", "details", "createdAt") VALUES ('21884fab-eb69-4fa9-9280-c22d54d36af1', 'b0011f32-03b6-46c7-bc71-67e75a91a177', 'UPDATE_PROFILE', 'Settings', 'Updated account profile details', '2026-07-20T12:42:56.582Z');
INSERT INTO "AuditLog" ("id", "userId", "action", "module", "details", "createdAt") VALUES ('27a3dc75-a11e-4908-9103-05026b4f819a', 'b0011f32-03b6-46c7-bc71-67e75a91a177', 'UPDATE_PROFILE', 'Settings', 'Updated account profile details', '2026-07-20T12:43:10.637Z');
INSERT INTO "AuditLog" ("id", "userId", "action", "module", "details", "createdAt") VALUES ('1da63b57-239b-4edd-860f-cad3de5e8a43', 'b0011f32-03b6-46c7-bc71-67e75a91a177', 'UPDATE_PROFILE', 'Settings', 'Updated account profile details', '2026-07-20T19:20:16.574Z');
INSERT INTO "AuditLog" ("id", "userId", "action", "module", "details", "createdAt") VALUES ('4ef8b3e3-c65b-41a5-81e0-3d73488ec04a', 'b0011f32-03b6-46c7-bc71-67e75a91a177', 'UPDATE_SETTINGS', 'Settings', 'Updated settings for category: general', '2026-07-20T20:43:08.095Z');
INSERT INTO "AuditLog" ("id", "userId", "action", "module", "details", "createdAt") VALUES ('b876cd2b-6a03-4434-9294-5748b5ff1c30', 'b0011f32-03b6-46c7-bc71-67e75a91a177', 'CHANGE_PASSWORD', 'Settings', 'Changed account password', '2026-07-20T20:44:40.175Z');
INSERT INTO "AuditLog" ("id", "userId", "action", "module", "details", "createdAt") VALUES ('9909fe8a-b56c-4a98-85a1-21e04ff55665', 'b0011f32-03b6-46c7-bc71-67e75a91a177', 'UPDATE_PROFILE', 'Settings', 'Changed account email to Noorullah1245', '2026-07-20T21:08:05.270Z');
INSERT INTO "AuditLog" ("id", "userId", "action", "module", "details", "createdAt") VALUES ('1b6679e7-e36d-46e0-8033-fffdd4c134aa', 'b0011f32-03b6-46c7-bc71-67e75a91a177', 'DATABASE_BACKUP', 'Settings', 'Created database backup', '2026-07-20T21:09:52.128Z');

